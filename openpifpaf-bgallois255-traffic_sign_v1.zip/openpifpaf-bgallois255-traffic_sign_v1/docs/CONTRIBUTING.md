Create a pull request with your suggested changes. Make sure your code passes
`pytest` and `pylint` checks.

E-mail a signed copy of the
[CLAI](https://github.com/openpifpaf/openpifpaf/blob/main/docs/CLAI.txt)
(and if applicable the
[CLAC](https://github.com/openpifpaf/openpifpaf/blob/main/docs/CLAC.txt))
as PDF file to research@svenkreiss.com.

Thanks.
