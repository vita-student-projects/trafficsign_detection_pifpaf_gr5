#include "openpifpaf/utils.hpp"


namespace openpifpaf {

void set_quiet(bool v) { quiet = v; }

}  // namespace openpifpaf
