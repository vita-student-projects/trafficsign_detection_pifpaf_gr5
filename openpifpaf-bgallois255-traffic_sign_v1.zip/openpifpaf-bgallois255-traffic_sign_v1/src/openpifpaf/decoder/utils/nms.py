import torch

# pylint: disable=invalid-name
Keypoints = torch.classes.openpifpaf_decoder_utils.NMSKeypoints
