import openpifpaf


def register():
    openpifpaf.DATAMODULES['testplugin'] = None
